# Исходный код к курсу по VueJS [2021]

Полный курс доступен на Youtube: https://youtu.be/1rRD9uMF92o
