<template>
  <div class="card">
    <h1>Страница не найдена</h1>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quia, repellendus!</p>
    <router-link to="/login">Авторизоваться</router-link>
  </div>
</template>