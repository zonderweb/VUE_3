<template>
  <div>
    <h2>Тема письма</h2>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Adipisci animi, cumque ea laborum laudantium nostrum odio quis soluta sunt velit?</p>
    <button class="btn">Закрыть</button>
  </div>
</template>

<script>
export default {
}
</script>

<style scoped>

</style>