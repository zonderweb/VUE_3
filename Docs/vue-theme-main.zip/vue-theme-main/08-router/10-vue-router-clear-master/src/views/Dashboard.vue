<template>
  <div class="card">
    <h1>Привет на главной</h1>

    <p>Тут ты можешь перейти на любую страницу и почитать заранее заготовленные письма :)</p>

    <router-link to="mail">To Mail</router-link>
  </div>
</template>

<script>
export default {
}
</script>

<style scoped>

</style>