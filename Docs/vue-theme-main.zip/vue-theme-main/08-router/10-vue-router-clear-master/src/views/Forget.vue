<template>
  <div class="card">
    <h2>Забыл пароль? Так вспоминай!</h2>

    <button class="btn" >Обратно к логину</button>
  </div>
</template>
