<template>
  <span :class="['badge']">Название статуса</span>
</template>