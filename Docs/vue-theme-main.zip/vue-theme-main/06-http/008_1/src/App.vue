<template>
  <div class="container">
    <div class="card">
      <h2>Работа с базой данных</h2>
    </div>
  </div>
</template>

<script>
export default {
}
</script>

<style>

</style>
