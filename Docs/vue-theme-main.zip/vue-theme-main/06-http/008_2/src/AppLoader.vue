<template>
  <div class="loader">Loading...</div>
</template>