<template>
  <h1>{{$attrs.value}}</h1>
</template>