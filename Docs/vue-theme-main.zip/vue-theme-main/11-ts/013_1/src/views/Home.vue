<template>
  <div class="card">
    <h1>Как Vue работает с TypeScript?</h1>



    <button class="btn">Открыть пользователей</button>
  </div>
</template>
