<template>
  <header class="navbar">
    Vuex
  </header>
</template>

<script>
  export default {

  }
</script>
