export default {
  changeTitle(state, payload) {
    state.appTitle = payload
  }
}