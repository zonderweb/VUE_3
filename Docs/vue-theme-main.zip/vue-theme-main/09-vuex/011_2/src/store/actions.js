export default {
  changeTitle({ commit }, payload) {
    commit('changeTitle', payload)
  }
}