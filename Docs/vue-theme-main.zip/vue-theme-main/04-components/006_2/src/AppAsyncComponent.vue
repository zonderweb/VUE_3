<template>
  <div>
    <h3>This is Async Component</h3>
  </div>
</template>

<script>
  export default {

  }
</script>

<style scoped>

</style>