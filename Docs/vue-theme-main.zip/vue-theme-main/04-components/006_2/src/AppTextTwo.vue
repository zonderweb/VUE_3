<template>
  <div class="card">
    <h3>Это компонент ДВА</h3>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Omnis, vel.</p>
    <hr />
    <small>Lorem ipsum dolor sit amet.</small>
  </div>
</template>

<script>
  export default {

  }
</script>

<style scoped>

</style>